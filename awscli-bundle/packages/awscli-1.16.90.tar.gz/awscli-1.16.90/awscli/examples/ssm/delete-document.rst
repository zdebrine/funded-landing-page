**To delete a document**

This example deletes a document. There is no output if the command succeeds.

Command::

  aws ssm delete-document --name "Config_2"
